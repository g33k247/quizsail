# QuizSail

Test Prep Engine

## Static Fork

The goal of this fork is to remove the hosted server requirement.

## Authors

- **John Matzen** - _Initial work_ - [jmatzen](https://github.com/jmatzen)
- L S - _Some CSS, HTML, JS_ - [SkillAllHumans](https://github.com/SkillAllHumans)
- lynda\_ - _c191 data_

## License

This project is licensed under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/).
